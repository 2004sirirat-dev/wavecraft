# Wavecraft

A song generator: type a prompt, pick a style, get real lyrics (Claude) and a real generated track (ElevenLabs Music).

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Copy `.env.example` to `.env.local` and fill in your keys:
   ```
   cp .env.example .env.local
   ```
   - `ANTHROPIC_API_KEY` — from console.anthropic.com
   - `ELEVENLABS_API_KEY` — from elevenlabs.io, **requires a Creator plan or higher** (the Music API is not available on the free tier)

3. Run it locally:
   ```
   npm run dev
   ```
   Visit http://localhost:3000

## Deploying to Vercel

1. Push this folder to a GitHub repo.
2. Import the repo in Vercel.
3. In the Vercel project settings, add the same two environment variables (`ANTHROPIC_API_KEY`, `ELEVENLABS_API_KEY`) under Settings → Environment Variables.
4. Deploy. Vercel will build the Next.js app and serve both the frontend and the two API routes automatically.

## How it works

- `/api/lyrics` — sends your prompt + chosen style to Claude, gets back structured lyrics (Intro/Verse/Chorus/Outro).
- `/api/generate-song` — sends those lyrics + style as a prompt to ElevenLabs' `POST /v1/music` endpoint, gets back an MP3, and streams it straight to the browser.
- The three "seed" cards in the discover feed are just visual placeholders (no real audio) — every song you actually generate gets prepended to the top of the feed with real, playable audio.

## Notes / next steps

- Currently there's no database — generated songs only live in the browser tab (refreshing loses them). Add a database (e.g. Postgres via Vercel Postgres or Supabase) plus object storage (S3/R2) if you want songs to persist and be shareable by URL.
- No auth or rate-limiting yet — anyone with access to the site can spend your API credits. Add both before sharing the link publicly.
- ElevenLabs Music is billed per second of generated audio (~$0.008/sec at last check) — worth adding a cap on max song length and/or generations per user.
